It is removes NoEscape.exe

Change the username on code Andrew to your username to use the tool

Important

1-The tool not removes Red User icons
2-The Tool not changes the registries
3-The tool removes payload regs
4-You remove other NoEscape Files on yours not the tool.
5-Tool removes the Noescape wallpaper to local appdata
Done!

Endermanch52